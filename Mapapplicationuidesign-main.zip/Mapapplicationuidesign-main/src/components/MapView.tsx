import { MapPin, Navigation } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import type { Marker } from '../App';

interface MapViewProps {
  markers: Marker[];
  onMarkerClick: (marker: Marker) => void;
  currentTime: Date;
  activeFilters: string[];
}

export function MapView({ markers, onMarkerClick, currentTime, activeFilters }: MapViewProps) {
  // Filter markers based on time and active filters
  const visibleMarkers = markers.filter(marker => {
    const timeMatch = marker.timestamp <= currentTime;
    const filterMatch = activeFilters.length === 0 || activeFilters.includes(marker.category);
    return timeMatch && filterMatch;
  });

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      'Office': 'bg-blue-500',
      'Meeting Point': 'bg-green-500',
      'Warehouse': 'bg-orange-500',
    };
    return colors[category] || 'bg-gray-500';
  };

  return (
    <div className="w-full h-full relative bg-slate-100">
      {/* Map placeholder with grid */}
      <div 
        className="absolute inset-0 bg-gradient-to-br from-slate-50 to-slate-200"
        style={{
          backgroundImage: `
            linear-gradient(to right, rgba(0,0,0,0.05) 1px, transparent 1px),
            linear-gradient(to bottom, rgba(0,0,0,0.05) 1px, transparent 1px)
          `,
          backgroundSize: '40px 40px'
        }}
      >
        {/* Map attribution text */}
        <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm px-3 py-2 rounded-lg shadow-sm">
          <p className="text-xs text-muted-foreground">Interactive Map View</p>
        </div>

        {/* Zoom controls */}
        <div className="absolute top-4 right-4 flex flex-col gap-2">
          <Button size="icon" variant="secondary" className="h-10 w-10 shadow-md">
            <span className="text-lg">+</span>
          </Button>
          <Button size="icon" variant="secondary" className="h-10 w-10 shadow-md">
            <span className="text-lg">−</span>
          </Button>
        </div>

        {/* Current location button */}
        <div className="absolute bottom-4 right-4">
          <Button size="icon" variant="secondary" className="h-12 w-12 shadow-md rounded-full">
            <Navigation className="h-5 w-5" />
          </Button>
        </div>

        {/* Markers */}
        <div className="absolute inset-0">
          {visibleMarkers.map((marker, index) => {
            // Simple positioning based on mock coordinates
            const left = 20 + (index * 25) % 70;
            const top = 20 + (index * 20) % 60;
            
            return (
              <button
                key={marker.id}
                onClick={() => onMarkerClick(marker)}
                className="absolute transform -translate-x-1/2 -translate-y-full group cursor-pointer"
                style={{ left: `${left}%`, top: `${top}%` }}
              >
                <div className="relative">
                  {/* Marker pin */}
                  <div className={`${getCategoryColor(marker.category)} h-10 w-10 rounded-full flex items-center justify-center shadow-lg border-2 border-white transition-transform group-hover:scale-110`}>
                    <MapPin className="h-5 w-5 text-white" />
                  </div>
                  
                  {/* Marker label */}
                  <div className="absolute top-full left-1/2 transform -translate-x-1/2 mt-1 whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity">
                    <Badge variant="secondary" className="shadow-md">
                      {marker.title}
                    </Badge>
                  </div>

                  {/* Pulse effect */}
                  <div className={`absolute inset-0 ${getCategoryColor(marker.category)} rounded-full animate-ping opacity-20`} />
                </div>
              </button>
            );
          })}
        </div>

        {/* Visible markers count */}
        <div className="absolute bottom-4 left-4 bg-white/90 backdrop-blur-sm px-3 py-2 rounded-lg shadow-sm">
          <p className="text-xs text-muted-foreground">
            Showing {visibleMarkers.length} of {markers.length} markers
          </p>
        </div>
      </div>
    </div>
  );
}
