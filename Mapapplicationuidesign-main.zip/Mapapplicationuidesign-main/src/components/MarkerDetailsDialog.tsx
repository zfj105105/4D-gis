import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { ScrollArea } from './ui/scroll-area';
import { Edit2, Share2, Trash2, FileText, Image, Clock, Paperclip } from 'lucide-react';
import type { Marker } from '../App';

interface MarkerDetailsDialogProps {
  marker: Marker | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onEdit: () => void;
  onShare: () => void;
  onDelete: () => void;
}

export function MarkerDetailsDialog({ 
  marker, 
  open, 
  onOpenChange,
  onEdit,
  onShare,
  onDelete 
}: MarkerDetailsDialogProps) {
  if (!marker) return null;

  const getFileIcon = (type: string) => {
    if (type.toLowerCase().includes('image')) return <Image className="h-4 w-4" />;
    return <FileText className="h-4 w-4" />;
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md max-h-[90vh] p-0 gap-0">
        <DialogHeader className="p-6 pb-4">
          <DialogTitle>{marker.title}</DialogTitle>
          <div className="flex items-center gap-2 mt-2">
            <Badge variant="secondary">{marker.category}</Badge>
            <span className="text-sm text-muted-foreground">
              {marker.timestamp.toLocaleDateString()}
            </span>
          </div>
        </DialogHeader>

        <Tabs defaultValue="details" className="flex-1 flex flex-col">
          <TabsList className="grid w-full grid-cols-3 mx-6">
            <TabsTrigger value="details">Details</TabsTrigger>
            <TabsTrigger value="attachments">Files</TabsTrigger>
            <TabsTrigger value="history">History</TabsTrigger>
          </TabsList>

          <ScrollArea className="flex-1 px-6">
            <TabsContent value="details" className="mt-4 space-y-4">
              <div>
                <h4 className="text-sm text-muted-foreground mb-2">Description</h4>
                <p className="text-sm">{marker.description}</p>
              </div>

              <Separator />

              <div>
                <h4 className="text-sm text-muted-foreground mb-3">Attributes</h4>
                <div className="space-y-3">
                  {marker.attributes.map((attr, index) => (
                    <div key={index} className="flex justify-between items-start">
                      <span className="text-sm text-muted-foreground">{attr.key}</span>
                      <span className="text-sm text-right">{attr.value}</span>
                    </div>
                  ))}
                </div>
              </div>

              <Separator />

              <div>
                <h4 className="text-sm text-muted-foreground mb-2">Location</h4>
                <p className="text-sm">
                  {marker.lat.toFixed(6)}, {marker.lng.toFixed(6)}
                </p>
              </div>
            </TabsContent>

            <TabsContent value="attachments" className="mt-4 space-y-2">
              {marker.attachments.length === 0 ? (
                <div className="text-center py-8 text-sm text-muted-foreground">
                  No attachments
                </div>
              ) : (
                marker.attachments.map((file, index) => (
                  <button
                    key={index}
                    className="w-full flex items-center gap-3 p-3 bg-secondary/50 hover:bg-secondary rounded-lg transition-colors text-left"
                  >
                    <div className="h-10 w-10 bg-background rounded flex items-center justify-center flex-shrink-0">
                      {getFileIcon(file.type)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm truncate">{file.name}</p>
                      <p className="text-xs text-muted-foreground">{file.type}</p>
                    </div>
                    <Paperclip className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                  </button>
                ))
              )}
            </TabsContent>

            <TabsContent value="history" className="mt-4 space-y-3">
              {marker.versionHistory.map((version, index) => (
                <div key={index} className="relative pl-6 pb-4 border-l-2 last:border-l-0">
                  <div className="absolute left-[-9px] top-0 h-4 w-4 rounded-full bg-primary border-2 border-background" />
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="text-xs">{version.version}</Badge>
                      <span className="text-xs text-muted-foreground">
                        {version.date.toLocaleDateString()}
                      </span>
                    </div>
                    <p className="text-sm">{version.changes}</p>
                  </div>
                </div>
              ))}
            </TabsContent>
          </ScrollArea>

          <Separator />

          <div className="flex items-center gap-2 p-6 pt-4">
            <Button onClick={onEdit} variant="outline" className="flex-1">
              <Edit2 className="h-4 w-4 mr-2" />
              Edit
            </Button>
            <Button onClick={onShare} variant="outline" className="flex-1">
              <Share2 className="h-4 w-4 mr-2" />
              Share
            </Button>
            <Button onClick={onDelete} variant="outline" className="flex-1 text-destructive hover:text-destructive">
              <Trash2 className="h-4 w-4 mr-2" />
              Delete
            </Button>
          </div>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
