import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Layers, MapPin, BarChart3, Eye, EyeOff } from 'lucide-react';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Checkbox } from './ui/checkbox';
import { Label } from './ui/label';
import { ScrollArea } from './ui/scroll-area';
import { Separator } from './ui/separator';
import type { Marker } from '../App';

interface DrawerMenuProps {
  markers: Marker[];
  onMarkerSelect: (marker: Marker) => void;
  activeFilters: string[];
  onFiltersChange: (filters: string[]) => void;
}

export function DrawerMenu({ markers, onMarkerSelect, activeFilters, onFiltersChange }: DrawerMenuProps) {
  const categories = Array.from(new Set(markers.map(m => m.category)));
  
  const toggleFilter = (category: string) => {
    if (activeFilters.includes(category)) {
      onFiltersChange(activeFilters.filter(f => f !== category));
    } else {
      onFiltersChange([...activeFilters, category]);
    }
  };

  const categoryStats = categories.map(cat => ({
    name: cat,
    count: markers.filter(m => m.category === cat).length,
  }));

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      'Office': 'bg-blue-500',
      'Meeting Point': 'bg-green-500',
      'Warehouse': 'bg-orange-500',
    };
    return colors[category] || 'bg-gray-500';
  };

  return (
    <div className="flex flex-col h-full">
      <div className="p-4 border-b">
        <h2>Menu</h2>
      </div>
      
      <Tabs defaultValue="layers" className="flex-1 flex flex-col">
        <TabsList className="grid w-full grid-cols-3 mx-4 mt-2">
          <TabsTrigger value="layers" className="text-xs">
            <Layers className="h-4 w-4 mr-1" />
            Layers
          </TabsTrigger>
          <TabsTrigger value="markers" className="text-xs">
            <MapPin className="h-4 w-4 mr-1" />
            Markers
          </TabsTrigger>
          <TabsTrigger value="stats" className="text-xs">
            <BarChart3 className="h-4 w-4 mr-1" />
            Stats
          </TabsTrigger>
        </TabsList>

        <ScrollArea className="flex-1 px-4">
          <TabsContent value="layers" className="mt-4 space-y-4">
            <div>
              <h3 className="mb-3">Layer Controls</h3>
              
              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 bg-secondary/50 rounded-lg">
                  <div className="flex items-center gap-2">
                    <Eye className="h-4 w-4 text-muted-foreground" />
                    <Label>Base Map</Label>
                  </div>
                  <Checkbox defaultChecked />
                </div>

                <div className="flex items-center justify-between p-3 bg-secondary/50 rounded-lg">
                  <div className="flex items-center gap-2">
                    <Eye className="h-4 w-4 text-muted-foreground" />
                    <Label>Markers</Label>
                  </div>
                  <Checkbox defaultChecked />
                </div>

                <div className="flex items-center justify-between p-3 bg-secondary/50 rounded-lg">
                  <div className="flex items-center gap-2">
                    <Eye className="h-4 w-4 text-muted-foreground" />
                    <Label>Labels</Label>
                  </div>
                  <Checkbox defaultChecked />
                </div>

                <div className="flex items-center justify-between p-3 bg-secondary/50 rounded-lg">
                  <div className="flex items-center gap-2">
                    <EyeOff className="h-4 w-4 text-muted-foreground" />
                    <Label>Heatmap</Label>
                  </div>
                  <Checkbox />
                </div>
              </div>

              <Separator className="my-4" />

              <h3 className="mb-3">Category Filters</h3>
              
              <div className="space-y-2">
                {categories.map(category => (
                  <div key={category} className="flex items-center justify-between p-3 bg-secondary/50 rounded-lg">
                    <div className="flex items-center gap-2">
                      <div className={`h-3 w-3 rounded-full ${getCategoryColor(category)}`} />
                      <Label>{category}</Label>
                    </div>
                    <Checkbox 
                      checked={activeFilters.length === 0 || activeFilters.includes(category)}
                      onCheckedChange={() => toggleFilter(category)}
                    />
                  </div>
                ))}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="markers" className="mt-4 space-y-2">
            <div className="flex items-center justify-between mb-3">
              <h3>All Markers</h3>
              <Badge variant="secondary">{markers.length}</Badge>
            </div>
            
            {markers.map(marker => (
              <button
                key={marker.id}
                onClick={() => onMarkerSelect(marker)}
                className="w-full text-left p-3 bg-secondary/50 hover:bg-secondary rounded-lg transition-colors"
              >
                <div className="flex items-start gap-3">
                  <div className={`${getCategoryColor(marker.category)} h-8 w-8 rounded-full flex items-center justify-center flex-shrink-0`}>
                    <MapPin className="h-4 w-4 text-white" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="truncate">{marker.title}</p>
                    <p className="text-xs text-muted-foreground truncate">{marker.description}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <Badge variant="outline" className="text-xs">{marker.category}</Badge>
                      <span className="text-xs text-muted-foreground">
                        {marker.timestamp.toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                </div>
              </button>
            ))}
          </TabsContent>

          <TabsContent value="stats" className="mt-4 space-y-4">
            <div>
              <h3 className="mb-3">Statistics Overview</h3>
              
              <div className="grid gap-3">
                <div className="p-4 bg-secondary/50 rounded-lg">
                  <p className="text-xs text-muted-foreground mb-1">Total Markers</p>
                  <p className="text-2xl">{markers.length}</p>
                </div>

                <div className="p-4 bg-secondary/50 rounded-lg">
                  <p className="text-xs text-muted-foreground mb-1">Categories</p>
                  <p className="text-2xl">{categories.length}</p>
                </div>

                <Separator />

                <div>
                  <p className="text-xs text-muted-foreground mb-3">By Category</p>
                  <div className="space-y-2">
                    {categoryStats.map(stat => (
                      <div key={stat.name} className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className={`h-3 w-3 rounded-full ${getCategoryColor(stat.name)}`} />
                          <span className="text-sm">{stat.name}</span>
                        </div>
                        <Badge variant="secondary">{stat.count}</Badge>
                      </div>
                    ))}
                  </div>
                </div>

                <Separator />

                <div>
                  <p className="text-xs text-muted-foreground mb-3">Recent Activity</p>
                  <div className="space-y-2">
                    {markers.slice(0, 5).map(marker => (
                      <div key={marker.id} className="text-sm">
                        <p className="truncate">{marker.title}</p>
                        <p className="text-xs text-muted-foreground">
                          {marker.timestamp.toLocaleDateString()} at {marker.timestamp.toLocaleTimeString()}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>
        </ScrollArea>
      </Tabs>
    </div>
  );
}
