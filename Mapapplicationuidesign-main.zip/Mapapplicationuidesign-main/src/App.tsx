import { useState } from 'react';
import { Sheet, SheetContent, SheetTrigger } from './components/ui/sheet';
import { Button } from './components/ui/button';
import { Menu, Layers, MapPin, BarChart3, X } from 'lucide-react';
import { MapView } from './components/MapView';
import { DrawerMenu } from './components/DrawerMenu';
import { TimelineControl } from './components/TimelineControl';
import { MarkerDetailsDialog } from './components/MarkerDetailsDialog';
import { SharingDialog } from './components/SharingDialog';

// Mock marker data
export interface Marker {
  id: string;
  title: string;
  lat: number;
  lng: number;
  category: string;
  timestamp: Date;
  description: string;
  attributes: { key: string; value: string }[];
  attachments: { name: string; type: string; url: string }[];
  versionHistory: { version: string; date: Date; changes: string }[];
}

const mockMarkers: Marker[] = [
  {
    id: '1',
    title: 'Downtown Office',
    lat: 40.7589,
    lng: -73.9851,
    category: 'Office',
    timestamp: new Date('2024-11-01T10:30:00'),
    description: 'Main office location in downtown area',
    attributes: [
      { key: 'Address', value: '123 Main St, New York, NY' },
      { key: 'Floor', value: '5th Floor' },
      { key: 'Capacity', value: '50 people' },
    ],
    attachments: [
      { name: 'floor_plan.pdf', type: 'PDF', url: '#' },
      { name: 'office_photo.jpg', type: 'Image', url: '#' },
    ],
    versionHistory: [
      { version: 'v1.2', date: new Date('2024-11-01'), changes: 'Updated capacity information' },
      { version: 'v1.1', date: new Date('2024-10-15'), changes: 'Added floor plan attachment' },
      { version: 'v1.0', date: new Date('2024-10-01'), changes: 'Initial creation' },
    ],
  },
  {
    id: '2',
    title: 'Central Park Meeting',
    lat: 40.7829,
    lng: -73.9654,
    category: 'Meeting Point',
    timestamp: new Date('2024-11-05T14:00:00'),
    description: 'Team building event location',
    attributes: [
      { key: 'Event Type', value: 'Team Building' },
      { key: 'Attendees', value: '25 people' },
      { key: 'Duration', value: '3 hours' },
    ],
    attachments: [
      { name: 'event_schedule.pdf', type: 'PDF', url: '#' },
    ],
    versionHistory: [
      { version: 'v1.0', date: new Date('2024-10-20'), changes: 'Initial creation' },
    ],
  },
  {
    id: '3',
    title: 'Warehouse Location',
    lat: 40.7489,
    lng: -73.9680,
    category: 'Warehouse',
    timestamp: new Date('2024-10-28T09:00:00'),
    description: 'Storage and distribution center',
    attributes: [
      { key: 'Size', value: '10,000 sq ft' },
      { key: 'Type', value: 'Distribution Center' },
      { key: 'Staff', value: '15 people' },
    ],
    attachments: [
      { name: 'inventory.xlsx', type: 'Excel', url: '#' },
      { name: 'warehouse_layout.jpg', type: 'Image', url: '#' },
    ],
    versionHistory: [
      { version: 'v1.1', date: new Date('2024-10-28'), changes: 'Updated inventory file' },
      { version: 'v1.0', date: new Date('2024-09-15'), changes: 'Initial creation' },
    ],
  },
];

export default function App() {
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [selectedMarker, setSelectedMarker] = useState<Marker | null>(null);
  const [sharingDialogOpen, setSharingDialogOpen] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date('2024-11-01T00:00:00'));
  const [timeGranularity, setTimeGranularity] = useState<'year' | 'month' | 'day' | 'hour'>('day');
  const [isPlaying, setIsPlaying] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState(1);
  const [activeFilters, setActiveFilters] = useState<string[]>([]);

  const handleMarkerClick = (marker: Marker) => {
    setSelectedMarker(marker);
  };

  const handleShare = () => {
    setSharingDialogOpen(true);
  };

  const handleEdit = () => {
    // Handle edit action
    console.log('Edit marker:', selectedMarker);
  };

  const handleDelete = () => {
    // Handle delete action
    console.log('Delete marker:', selectedMarker);
    setSelectedMarker(null);
  };

  return (
    <div className="flex flex-col h-screen bg-background overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b bg-card">
        <Sheet open={drawerOpen} onOpenChange={setDrawerOpen}>
          <SheetTrigger asChild>
            <Button variant="outline" size="icon">
              <Menu className="h-5 w-5" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-[85vw] sm:w-96 p-0">
            <DrawerMenu 
              markers={mockMarkers} 
              onMarkerSelect={handleMarkerClick}
              activeFilters={activeFilters}
              onFiltersChange={setActiveFilters}
            />
          </SheetContent>
        </Sheet>
        <h1 className="flex-1 text-center">Map Application</h1>
        <div className="w-10" /> {/* Spacer for centering */}
      </div>

      {/* Main Map View */}
      <div className="flex-1 relative overflow-hidden">
        <MapView 
          markers={mockMarkers} 
          onMarkerClick={handleMarkerClick}
          currentTime={currentTime}
          activeFilters={activeFilters}
        />
      </div>

      {/* Timeline Control */}
      <div className="border-t bg-card">
        <TimelineControl
          currentTime={currentTime}
          onTimeChange={setCurrentTime}
          granularity={timeGranularity}
          onGranularityChange={setTimeGranularity}
          isPlaying={isPlaying}
          onPlayingChange={setIsPlaying}
          playbackSpeed={playbackSpeed}
          onSpeedChange={setPlaybackSpeed}
        />
      </div>

      {/* Marker Details Dialog */}
      <MarkerDetailsDialog
        marker={selectedMarker}
        open={!!selectedMarker}
        onOpenChange={(open) => !open && setSelectedMarker(null)}
        onEdit={handleEdit}
        onShare={handleShare}
        onDelete={handleDelete}
      />

      {/* Sharing Dialog */}
      <SharingDialog
        open={sharingDialogOpen}
        onOpenChange={setSharingDialogOpen}
        markerTitle={selectedMarker?.title || ''}
      />
    </div>
  );
}
